*Presence of _______ is must is to proceed ahead with installation of grunt
Node.js

*Which takes care of performing the repetitive mundane work in Grunt.js?
Task runner

*Registering of tasks happens within
Gruntfile






*CSS with superpowers' : This refers to _____________
SASS

*Which of these is officially maintained grunt plug in?
contrib-less 

*Grunt does not allow users to add their custom developed plug-ins and publish them to npm.
False

*Grunt prefers____ model approach to coding.
Configuration





*How can one reduce the size of images using grunt?
grunt-contrib-imagemin

*Which plug-in assists with cleaning of the unwanted folders & files
grunt-contrib-clean

*Which plug-in helps with revisioning the files ?
grunt-filerev

*The grunt plug-in to remove any unwanted CSS within project is _________
grunt-uncss

*Which plug-in takes care of sending automatic notifications?
grunt-notify

*Which grunt plug-in would be of use if you would like to monitor set of .js files and take any appropriate actions if any changes happens to them?
Watch

*After installing any plug-ins, the file which would reflect the dependency changes automatically ________________
package.json

*After installing the required plug-ins, the next activity would be _______
Add the plug-in in gruntfile through loadNpmTasks





*Banner in gruntfile becomes the __________
Commented Header of the file

*Which plug-in assists with injection of bower dependency code ?
grunt-wiredep

*Grunt.js helps with simplification through automation. Is this true or false ?
True

*Can one create his own plug-in and add to the grunt library ?
Yes

*While installing grunt.js, the cli in "$ npm install grunt-cli -g" represents
Command line interface

*The 3 main actions to be performed in gruntfile include
Configurations , loading plug-ins, Register tasks

*The plug-in used for Uglify is
contrib-uglify

*Which of these is not an example of the operations of the Task runner?
Splitting files

*The number of plug-ins available in grunt is around
6000+

*Which plug-in helps with validation of the js files ?
grunt-contrib-jshint

*SASS expands to ______________
Syntactically Awesome Style Sheets



*The final step of creating a plug-in is
publish

*While installing grunt.js, the g in "$ npm install grunt-cli -g" represents
Global

